<?php
function speak($con,$txt,$ortxt)
{
	$sql="select reply from chatbot_hints where question like '%$txt%'";
$res=mysqli_query($con,$sql);
// if(mysqli_num_rows($res)>0){echo "fuck";}


if(mysqli_num_rows($res)>0){
	$row=mysqli_fetch_assoc($res);
	$html=$row['reply'];
}
else{
	$html="Sorry not be able to understand you";
}
	$added_on=date('Y-m-d h:i:s');
	mysqli_query($con,"insert into message(message,added_on,type) values('$ortxt','$added_on','user')");
	$added_on=date('Y-m-d h:i:s');
	mysqli_query($con,"insert into message(message,added_on,type) values('$html','$added_on','bot')");
	echo $html;

}



function ask_product_speak($con,$txt,$ortxt)
{
	$sql="select * from goods where Goods_Name like '%$txt%'";
$res=mysqli_query($con,$sql);
// if(mysqli_num_rows($res)>0){echo "fuck";}
if(mysqli_num_rows($res)>0){
	$row=mysqli_fetch_assoc($res);
	$url = $row['Goods_URL'];

	$html="產品名稱: ".$row['Goods_Name']."<br>"."產品價格: ".$row['Goods_Price']."<br>"."產品規格: ".$row['Goods_Statement']."<br>"."產品分類: ".$row['Goods_Classify']."<br>"."產品url:"."<a href=$url>連結按我</a>"."<br>"."******************"."<br>";
}
else{
	$html="Sorry not be able to understand you";
}
	$added_on=date('Y-m-d h:i:s');
	mysqli_query($con,"insert into message(message,added_on,type) values('$ortxt','$added_on','user')");
	$added_on=date('Y-m-d h:i:s');
	mysqli_query($con,"insert into message(message,added_on,type) values('$html','$added_on','bot')");
	echo $html;

}

function random_select($con,$ortxt)
{
	
	$a=rand(1,counter($con));
	$sql="SELECT * FROM `goods` WHERE Goods_ID = $a";
$res=mysqli_query($con,$sql);
// if(mysqli_num_rows($res)>0){echo "fuck";}
if(mysqli_num_rows($res)>0){
	$row=mysqli_fetch_assoc($res);
	$url = $row['Goods_URL'];

	$html="產品名稱: ".$row['Goods_Name']."<br>"."產品價格: ".$row['Goods_Price']."<br>"."產品規格: ".$row['Goods_Statement']."<br>"."產品分類: ".$row['Goods_Classify']."<br>"."產品url:"."<a href=$url>連結按我</a>"."<br>"."******************"."<br>";
}
else{
	$html="Sorry not be able to understand you";
}
	$added_on=date('Y-m-d h:i:s');
	mysqli_query($con,"insert into message(message,added_on,type) values('$ortxt','$added_on','user')");
	$added_on=date('Y-m-d h:i:s');
	mysqli_query($con,"insert into message(message,added_on,type) values('$html','$added_on','bot')");
	echo $html;

}
function delete_all($con)
{
	$sql="DELETE FROM message;";
	$res=mysqli_query($con,$sql);
	return;
}

// if(mysqli_num_rows($res)>0){echo "fuck";}

function counter($con)
{
	$sql = "SELECT Goods_ID FROM `goods`";
	$res=mysqli_query($con,$sql);
	$a = mysqli_num_rows($res);
	return $a;
	
}

date_default_timezone_set('Asia/Kolkata');
include('database.inc.php');
$txt=mysqli_real_escape_string($con,$_POST['txt']);
static $i1 = 0;
if (preg_match("/(.*幹你*)|(.*肏你*)|(.*操你*)|(.*fuck*)/", $txt))
{
	$ortxt = $txt;
	counter($con);
	speak($con,$ortxt);
	
}
if (preg_match("/(.*本日推薦|隨機推薦*)/", $txt))
{
	$ortxt = $txt;
	counter($con);
	$txt = '幹你';random_select($con,$txt,$ortxt);
	
}
else if(preg_match("/(.*你好*)|(.*好棒*)|(.*麼棒*)|(.*good*job*)/", $txt))
{
	$ortxt = $txt;$txt = '棒';speak($con,$txt,$ortxt);
}
else if(preg_match("/(.*購物車*)/", $txt))
{
	$ortxt = $txt;$txt = '購物車';speak($con,$txt,$ortxt);
	
}
else if(preg_match("/(.*我想要買*)/", $txt))
{
	$ortxt = $txt;$ortxt = $txt;$txt = '我想要買';speak($con,$txt,$ortxt);
	
}
else if(preg_match("/(.*你們有賣筆電|你們有賣筆電|你們有賣鍵盤|你們有賣耳機*)/", $txt))
{
	$ortxt = $txt;$txt = '我們有賣';speak($con,$txt,$ortxt);
	
}
else if(preg_match("/(.*你們有賣李彥宏*)/", $txt))
{
	$ortxt = $txt;$txt = '李彥宏';ask_product_speak($con,$txt,$ortxt);
	
}
else if(preg_match("/(.*你們有賣^筆電*)/", $txt))
{
	$ortxt = $txt;$txt = '我們沒賣';speak($con,$txt,$ortxt);
	
}
else if(preg_match("/(.*早安|午安|晚安*)/", $txt))
{
	$ortxt = $txt;$txt = '我們有賣';speak($con,$txt,$ortxt);
	
}
else if(preg_match("/(.*刪除所有訊息|clear*)/", $txt))
{
	$ortxt = $txt;delete_all($con);
	echo "成功刪除，請重新整理頁面";
	// $ortxt = $txt;delete_all($con);speak($con,$txt,$ortxt);
	
}
else{
	$ortxt = $txt;speak($con,$txt,$ortxt);
}

?>